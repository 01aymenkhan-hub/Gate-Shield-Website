(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__02i_hkrn-8f_0._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/src_1u7bap71utla5._.js","static/chunks/node_modules_1l5tijlb808b3._.js"],
    source: "entry"
});
