1:"$Sreact.fragment"
2:"/_next/static/chunks/0umf92h1sb77c.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
6:"/_next/static/chunks/3yypahgh5lj2t.js"
7:"ContactModalProvider"
8:I[8638,["$2","$6"],"$7"]
9:"ScrollAnimations"
a:I[65418,["$2","$6"],"$9"]
b:I[3265,["$2","$6"],"Navbar"]
c:I[37538,["$2","$6"],"HeroFold"]
d:I[4672,["$2","$6"],"StatsFold"]
e:"WhyGateShieldFold"
f:I[49745,["$2","$6"],"$e"]
10:I[70482,["$2","$6"],"ModulesFold"]
11:I[52715,["$2","$6"],"FeaturesFold"]
12:I[90325,["$2","$6"],"WorkflowFold"]
13:I[94463,["$2","$6"],"PricingFold"]
14:I[99561,["$2","$6"],"IndustriesFold"]
15:I[95437,["$2","$6"],"CtaFold"]
16:I[58234,["$2","$6"],"Footer"]
17:I[97367,["$2"],"OutletBoundary"]
18:"$Sreact.suspense"
1a:"ViewportBoundary"
1b:I[97367,["$2"],"$1a"]
1d:"MetadataBoundary"
1e:I[97367,["$2"],"$1d"]
20:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/3py1uaaj2qxlq.css","style"]
:HL["/_next/static/media/07c7676b89ed2778-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/abc90e3a599e849c-s.p.2y2uoi4t910qy.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:[["children",{"s":"__PAGE__","h":512,"d":{"r":["$","$1","c",{"children":[["$","$L8",null,{"children":[["$","$La",null,{}],["$","$Lb",null,{}],["$","main",null,{"children":[["$","$Lc",null,{}],["$","div",null,{"className":"light-canvas-wrapper light-canvas-top","children":["$","$Ld",null,{}]}],["$","$Lf",null,{}],["$","div",null,{"className":"light-canvas-wrapper light-canvas-bottom","children":[["$","$L10",null,{}],["$","$L11",null,{}],["$","$L12",null,{}],["$","$L13",null,{}],["$","$L14",null,{}]]}],["$","$L15",null,{}]]}],["$","$L16",null,{}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/3yypahgh5lj2t.js","async":true,"nonce":"$undefined"}]],["$","$L17",null,{"children":["$","$18",null,{"name":"Next.MetadataOutlet","children":"$@19"}]}]]}],"p":false,"v":null}}]]
0:{"P":null,"c":["",""],"q":"","i":false,"t":{"t":{"s":"","h":528,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3py1uaaj2qxlq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0umf92h1sb77c.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"giF-bG_variable T7XERq_variable","children":["$","body",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":false,"v":null},"c":"$Q5"},"h":{"r":["$","$1","h",{"children":[null,["$","$L1b",null,{"children":"$L1c"}],["$","$L1e",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$18",null,{"name":"Next.Metadata","children":"$L1f"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":false,"v":null}},"m":"$undefined","G":["$20",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3py1uaaj2qxlq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$undefined","s":"$undefined","a":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"On4_9o0vqjnhRkVfa2eGf"}
1c:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
19:null
1f:[["$","title","0",{"children":"GateShield — Modern Workplace Visitor & Security Management"}],["$","meta","1",{"name":"description","content":"Move beyond paper registers with faster check-ins, QR-code passes, watchlist screening, and organized digital records."}]]
