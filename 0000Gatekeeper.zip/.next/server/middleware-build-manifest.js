globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/On4_9o0vqjnhRkVfa2eGf/_buildManifest.js",
    "static/On4_9o0vqjnhRkVfa2eGf/_ssgManifest.js",
    "static/On4_9o0vqjnhRkVfa2eGf/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/2r4s4h5xul1n-.js",
    "static/chunks/216iyidhmrh3u.js",
    "static/chunks/1-9dyrc39prri.js",
    "static/chunks/turbopack-3-ry682tkyiqk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1-9dyrc39prri.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1-9dyrc39prri.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/216iyidhmrh3u.js",
        "static/chunks/1-9dyrc39prri.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
