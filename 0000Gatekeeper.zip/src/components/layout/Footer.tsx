'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronUp } from 'lucide-react';
import { landingData } from '@/data/landingData';

export const Footer: React.FC = () => {
  const { navigation } = landingData;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="footer-section">
      <div className="footer-container">
        {/* Main Clean Row: Brand Logo on Left, Navigation on Right */}
        <div className="footer-main-row">
          <div className="footer-brand-wrap">
            <Link href="/" className="footer-logo-link">
              <Image
                src="/logo/logo-white.png"
                alt="GateShield Logo"
                width={150}
                height={38}
                className="footer-logo-img"
              />
            </Link>
            <p className="footer-short-desc">
              Smart workplace security & visitor management. Powered by{' '}
              <a
                href="https://artxpro.com"
                target="_blank"
                rel="noopener noreferrer"
                className="footer-agency-link"
              >
                artxpro.com
              </a>
            </p>
          </div>

          <nav className="footer-nav-links" aria-label="Footer Navigation">
            {navigation.links.map((link) => (
              <Link key={link.href} href={link.href} className="footer-nav-link">
                {link.label}
              </Link>
            ))}
            <Link
              href={navigation.ctaWhatsApp.href}
              target="_blank"
              rel="noopener noreferrer"
              className="footer-nav-link footer-wa-link"
            >
              WhatsApp
            </Link>
          </nav>
        </div>

        {/* Minimal Bottom Bar */}
        <div className="footer-bottom-bar">
          <p className="footer-copyright">
            © {new Date().getFullYear()} GateShield · Powered by{' '}
            <a
              href="https://artxpro.com"
              target="_blank"
              rel="noopener noreferrer"
              className="footer-agency-link"
            >
              Artxpro
            </a>
            . All rights reserved.
          </p>

          <button
            type="button"
            className="footer-back-to-top"
            onClick={scrollToTop}
            aria-label="Scroll back to top"
          >
            <span>Back to top</span>
            <ChevronUp size={14} />
          </button>
        </div>
      </div>
    </footer>
  );
};
