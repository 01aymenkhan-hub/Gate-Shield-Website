'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import {
  ShieldCheck,
  MessageCircle,
  Check,
  Clock,
  Star,
  Home,
  QrCode,
  User,
  History,
  Shield,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { landingData } from '@/data/landingData';

interface HeroScene {
  id: string;
  tabLabel: string;
  ambientLabel: string;
  ambientTime: string;
  bgImage: string;
  visitorName: string;
  statusBadge: string;
  score: string;
  currentStep: string;
  nextStep: string;
  notifHeadline: string;
  notifDesc: string;
}

const HERO_SCENES: HeroScene[] = [
  {
    id: 'scene-1',
    tabLabel: '09:00 CHECK-IN',
    ambientLabel: 'LOBBY',
    ambientTime: '09:00',
    bgImage: '/images/hero-scene-1.webp',
    visitorName: 'David Vance',
    statusBadge: '1/3 SCANNING',
    score: '33%',
    currentStep: 'CNIC ID Scanned',
    nextStep: 'Host Approval Pending',
    notifHeadline: 'ID Scanned: David Vance',
    notifDesc: 'CNIC verified. Awaiting 1-tap host confirmation.',
  },
  {
    id: 'scene-2',
    tabLabel: '09:01 SECURITY SCAN',
    ambientLabel: 'SCAN',
    ambientTime: '09:01',
    bgImage: '/images/hero-scene-2.webp', // Runner image from user's screenshot
    visitorName: 'Sarah Jenkins',
    statusBadge: '2/4 TODAY',
    score: '13 days',
    currentStep: 'Watchlist Screened',
    nextStep: 'QR Badge Issued',
    notifHeadline: 'GateShield Verified',
    notifDesc: 'Pass active. Gate 02 turnstile access granted.',
  },
  {
    id: 'scene-3',
    tabLabel: '09:02 Visitor Entered',
    ambientLabel: 'Entered',
    ambientTime: '09:02',
    bgImage: '/images/hero-scene-3.webp',
    visitorName: 'Alex Thorne',
    statusBadge: '3/3 CLEAR',
    score: '100%',
    currentStep: 'Room B Booked',
    nextStep: 'Catering Requested',
    notifHeadline: 'Room B Unlocked: Alex Thorne',
    notifDesc: 'Meeting in Conference Room B started on time.',
  },
  {
    id: 'scene-4',
    tabLabel: '12:00 Visitor Exit',
    ambientLabel: 'EXIT',
    ambientTime: '12:00',
    bgImage: '/images/hero-scene-4.webp',
    visitorName: 'Maya Lin',
    statusBadge: 'COMPLETED',
    score: 'Logged',
    currentStep: 'QR Checked-Out',
    nextStep: 'Digital Log Archived',
    notifHeadline: 'Visitor Exit Logged',
    notifDesc: 'Audit trail recorded. Tamper-proof record sealed.',
  },
];

export const HeroFold: React.FC = () => {
  // Default to scene index 1 (the runner image matching the screenshot)
  const [activeSceneIndex, setActiveSceneIndex] = useState(1);
  const activeScene = HERO_SCENES[activeSceneIndex];
  const { fold1Hero } = landingData;

  // Auto-advance or allow user interactive selection
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSceneIndex((prev) => (prev + 1) % HERO_SCENES.length);
    }, 9000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="hero-section" id="hero">
      {/* Background Images Layer */}
      {HERO_SCENES.map((scene, idx) => (
        <div
          key={scene.id}
          className={`hero-bg-layer ${idx === activeSceneIndex ? 'active' : ''}`}
        >
          <Image
            src={scene.bgImage}
            alt="Workplace and lifestyle context"
            fill
            priority={idx === 1}
            className="hero-bg-image"
          />
        </div>
      ))}

      {/* Dark Ambient Vignette Overlay */}
      <div className="hero-overlay" />

      {/* Main Hero Container */}
      <div className="hero-container">
        {/* Left Column: Headlines & Dual Store-style CTAs */}
        <div className="hero-left">
          {/* Ambient Time Indicator (Exact structure from SS: RUN / 07:40) */}
          <div className="hero-ambient-time">
            <div className="time-label">{activeScene.ambientLabel}</div>
            <div className="time-value">{activeScene.ambientTime}</div>
          </div>

          {/* Pill Badge */}
          <div className="hero-pill-badge">
            <span className="dot" />
            <span>New · GateShield 3.0 with Smart QR Screening</span>
          </div>

          {/* Main Headline with Accent Line */}
          <h1 className="hero-heading">
            A Smarter Way to
            <span className="accent-text">Welcome Every Visitor.</span>
          </h1>

          {/* Subheading */}
          <p className="hero-subheading">{fold1Hero.subheading}</p>

          {/* Dual Store-Style CTA Cards */}
          <div className="hero-cta-group">
            {/* Primary Action: Contact & Book Demo */}
            <Link
              href="#pricing"
              className="hero-cta-card primary"
            >
              <div className="hero-cta-icon">
                <ShieldCheck size={22} />
              </div>
              <div className="hero-cta-text">
                <span className="hero-cta-sub">Instant Setup</span>
                <span className="hero-cta-title">Contact & Demo</span>
              </div>
            </Link>

            {/* WhatsApp Direct Action */}
            <Link
              href={fold1Hero.whatsappCta.href}
              target="_blank"
              rel="noopener noreferrer"
              className="hero-cta-card whatsapp"
            >
              <div className="hero-cta-icon">
                <MessageCircle size={22} />
              </div>
              <div className="hero-cta-text">
                <span className="hero-cta-sub">Instant Response</span>
                <span className="hero-cta-title">Chat on WhatsApp</span>
              </div>
            </Link>
          </div>

          {/* Agency Trust Endorsement Strip */}
          <div className="hero-trust-bar">
            <span className="hero-trust-dot" />
            <span>
              Powered by{' '}
              <a
                href="https://artxpro.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hero-agency-link"
              >
                Artxpro
              </a>{' '}
              · Premier Digital Agency & Enterprise Infrastructure
            </span>
          </div>
        </div>

        {/* Right Column: Realistic Phone Mockup & Floating Notification */}
        <div className="hero-right">
          <div className="phone-mockup-wrapper">
            <div className="phone-mockup-screen">
              {/* Dynamic Island Status Bar */}
              <div className="phone-island-bar">
                <span>07:46</span>
                <div className="phone-island-pill">
                  <span className="island-dot" />
                  <span>GateShield Active</span>
                </div>
                <span>100%</span>
              </div>

              {/* Screen Body */}
              <div className="phone-screen-body">
                <div className="phone-date-tag">TUE, 28 OCT · GATE 02</div>
                <div className="phone-greeting">
                  Keep going, {activeScene.visitorName.split(' ')[0]}
                </div>

                {/* Dark Status Card (Exact layout from SS with 2/4 and mini bars) */}
                <div className="phone-card-dark">
                  <div className="phone-stat-ring">
                    <svg viewBox="0 0 36 36">
                      <circle className="circle-bg" cx="18" cy="18" r="14" />
                      <circle className="circle-fill" cx="18" cy="18" r="14" />
                    </svg>
                    <span className="ring-number">2/4</span>
                  </div>

                  <div className="phone-card-text">
                    <div className="phone-card-label">SECURITY PASS</div>
                    <div className="phone-card-val">13 days streak</div>
                    <div className="phone-mini-bars">
                      <span className="phone-mini-bar active" style={{ height: '60%' }} />
                      <span className="phone-mini-bar active" style={{ height: '80%' }} />
                      <span className="phone-mini-bar active" style={{ height: '40%' }} />
                      <span className="phone-mini-bar active" style={{ height: '100%' }} />
                      <span className="phone-mini-bar" style={{ height: '50%' }} />
                      <span className="phone-mini-bar" style={{ height: '70%' }} />
                    </div>
                  </div>
                </div>

                {/* Checklist (Checkmarks as in SS) */}
                <div className="phone-checklist">
                  <div className="phone-check-item">
                    <div className="phone-check-left">
                      <span className="phone-check-icon">
                        <Check size={11} strokeWidth={3} />
                      </span>
                      <span>Morning check-in</span>
                    </div>
                    <span className="phone-check-time">07:10</span>
                  </div>

                  <div className="phone-check-item">
                    <div className="phone-check-left">
                      <span className="phone-check-icon">
                        <Check size={11} strokeWidth={3} />
                      </span>
                      <span>Security scan</span>
                    </div>
                    <span className="phone-check-time">07:40</span>
                  </div>

                  <div className="phone-check-item">
                    <div className="phone-check-left">
                      <span className="phone-check-icon circle-outline" />
                      <span>Deep work block</span>
                    </div>
                    <span className="phone-check-time">14:00</span>
                  </div>

                  <div className="phone-check-item">
                    <div className="phone-check-left">
                      <span className="phone-check-icon circle-outline" />
                      <span>Read 20 pages</span>
                    </div>
                    <span className="phone-check-time">21:30</span>
                  </div>
                </div>
              </div>

              {/* Phone Bottom Tab Bar */}
              <div className="phone-bottom-nav">
                <Home size={17} className="active-icon" />
                <Clock size={17} />
                <QrCode size={17} />
                <User size={17} />
              </div>
            </div>

            {/* Overlapping Floating Notification (Exact layout from SS!) */}
            <div className="hero-floating-notification">
              <div className="notif-header">
                <div className="notif-app-info">
                  <div className="notif-app-icon">G</div>
                  <span className="notif-app-name">GATESHIELD</span>
                </div>
                <span className="notif-time">now</span>
              </div>
              <div className="notif-title">Pass verified, Gate 02</div>
              <div className="notif-desc">
                QR pass validated. Visitor {activeScene.visitorName} authorized for entry.
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Hero Bottom Timeline Slider Bar (Exact 4 stages from SS!) */}
      <div className="hero-bottom-timeline">
        <div className="timeline-track">
          {HERO_SCENES.map((scene, idx) => (
            <button
              key={scene.id}
              type="button"
              className={`timeline-step-btn ${idx === activeSceneIndex ? 'active' : ''}`}
              onClick={() => setActiveSceneIndex(idx)}
            >
              <span className="step-title-text">{scene.tabLabel}</span>
              <span className="step-indicator-bar" />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
