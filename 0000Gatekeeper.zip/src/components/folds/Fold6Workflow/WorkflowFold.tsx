'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  ScanLine,
  UserCheck,
  ShieldCheck,
  QrCode,
  CheckCircle2,
  Wifi,
  AlertTriangle,
  Clock,
  ChevronRight,
} from 'lucide-react';

/* ─── Step Data ─────────────────────────────────────────────────────────────── */

interface WorkflowStep {
  num: string;
  time: string;
  title: string;
  desc: string;
  icon: React.ReactNode;
  phone: PhoneContent;
}

interface PhoneContent {
  statusBar: string;
  badge: string;
  badgeColor: 'blue' | 'green' | 'amber' | 'purple';
  screenTitle: string;
  screenSub: string;
  body: React.ReactNode;
  footerLabel: string;
  footerSub: string;
}

const STEPS: WorkflowStep[] = [
  {
    num: '01',
    time: '09:00',
    title: 'Scan the ID',
    desc: "The visitor presents their CNIC or Driving Licence at the kiosk. Gate Shield's scanner reads it in under 3 seconds — no manual typing needed.",
    icon: <ScanLine size={20} />,
    phone: {
      statusBar: '09:00',
      badge: 'SCANNING',
      badgeColor: 'blue',
      screenTitle: 'Place ID on Scanner',
      screenSub: 'CNIC · Driving Licence · Passport',
      body: (
        <div className="wf-phone-scan-area">
          <div className="wf-scan-frame">
            <span className="wf-scan-corner tl" />
            <span className="wf-scan-corner tr" />
            <span className="wf-scan-corner bl" />
            <span className="wf-scan-corner br" />
            <div className="wf-scan-beam" />
            <div className="wf-scan-id-mock">
              <div className="wf-id-chip" />
              <div className="wf-id-line long" />
              <div className="wf-id-line med" />
              <div className="wf-id-line short" />
            </div>
          </div>
          <p className="wf-phone-hint">Hold steady · Scanning…</p>
        </div>
      ),
      footerLabel: 'Auto-capture on detect',
      footerSub: 'Avg read time: 2.4s',
    },
  },
  {
    num: '02',
    time: '09:01',
    title: 'Fetch Visitor Details',
    desc: 'Visitor data auto-fills in real time. Name, photo, and CNIC number are extracted instantly — then cross-checked against the watchlist database.',
    icon: <UserCheck size={20} />,
    phone: {
      statusBar: '09:01',
      badge: 'AUTO-FILL',
      badgeColor: 'purple',
      screenTitle: 'Visitor Identified',
      screenSub: 'Details extracted · Watchlist checked',
      body: (
        <div className="wf-phone-profile">
          <div className="wf-profile-avatar">AK</div>
          <div className="wf-profile-info">
            <div className="wf-profile-name">Ahmed Khan</div>
            <div className="wf-profile-meta">CNIC: 35202-XXXXXX-3</div>
            <div className="wf-profile-meta">Visiting: Sana Ali · HR Dept</div>
          </div>
          <div className="wf-watchlist-row">
            <CheckCircle2 size={14} color="#10b981" />
            <span className="wf-watchlist-clear">Watchlist Clear</span>
          </div>
          <div className="wf-profile-fields">
            <div className="wf-field-row">
              <span className="wf-field-label">Purpose</span>
              <span className="wf-field-val">Job Interview</span>
            </div>
            <div className="wf-field-row">
              <span className="wf-field-label">Host</span>
              <span className="wf-field-val">Sana Ali</span>
            </div>
            <div className="wf-field-row">
              <span className="wf-field-label">Floor</span>
              <span className="wf-field-val">Floor 3 · Cabin 12</span>
            </div>
          </div>
        </div>
      ),
      footerLabel: 'Watchlist screened',
      footerSub: '0 flags detected',
    },
  },
  {
    num: '03',
    time: '09:02',
    title: 'Verify the Details',
    desc: 'The guard reviews the pre-filled form and the host receives a 1-tap approval notification on their phone. No calls, no waiting — done in seconds.',
    icon: <ShieldCheck size={20} />,
    phone: {
      statusBar: '09:02',
      badge: 'PENDING',
      badgeColor: 'amber',
      screenTitle: 'Awaiting Host Approval',
      screenSub: 'Notification sent to Sana Ali',
      body: (
        <div className="wf-phone-approval">
          <div className="wf-approval-notif">
            <div className="wf-notif-icon-wrap">
              <ShieldCheck size={18} color="#3a57a1" />
            </div>
            <div className="wf-notif-body">
              <div className="wf-notif-title">GateShield · Visitor Alert</div>
              <div className="wf-notif-desc">Ahmed Khan is at reception for you.</div>
              <div className="wf-notif-actions">
                <button className="wf-notif-btn approve">✓ Approve</button>
                <button className="wf-notif-btn deny">✕ Deny</button>
              </div>
            </div>
          </div>
          <div className="wf-guard-check-row">
            <div className="wf-guard-check-item done">
              <CheckCircle2 size={13} />
              <span>ID Verified</span>
            </div>
            <div className="wf-guard-check-item done">
              <CheckCircle2 size={13} />
              <span>Watchlist Clear</span>
            </div>
            <div className="wf-guard-check-item pending">
              <Clock size={13} />
              <span>Host Confirming…</span>
            </div>
          </div>
        </div>
      ),
      footerLabel: 'Host notified instantly',
      footerSub: 'Avg response: 8 seconds',
    },
  },
  {
    num: '04',
    time: '09:03',
    title: 'Generate QR Pass',
    desc: 'Once approved, a timestamped digital QR pass is issued instantly. It grants zone-specific access and auto-expires at the end of the visit.',
    icon: <QrCode size={20} />,
    phone: {
      statusBar: '09:03',
      badge: 'APPROVED',
      badgeColor: 'green',
      screenTitle: 'Entry Pass Issued',
      screenSub: 'Scan at turnstile · Auto-expires 6:00 PM',
      body: (
        <div className="wf-phone-pass">
          <div className="wf-pass-card">
            <div className="wf-pass-header">
              <span className="wf-pass-org">GATE SHIELD</span>
              <span className="wf-pass-badge">● ACTIVE</span>
            </div>
            <div className="wf-pass-qr">
              <div className="wf-qr-grid">
                {Array.from({ length: 25 }).map((_, i) => (
                  <div
                    key={i}
                    className="wf-qr-cell"
                    style={{ opacity: Math.random() > 0.45 ? 1 : 0 }}
                  />
                ))}
              </div>
            </div>
            <div className="wf-pass-visitor">Ahmed Khan</div>
            <div className="wf-pass-meta">Floor 3 · HR Department</div>
            <div className="wf-pass-meta">Valid: 09:03 AM – 06:00 PM</div>
          </div>
        </div>
      ),
      footerLabel: 'QR pass generated',
      footerSub: 'Turnstile access unlocked',
    },
  },
];

/* ─── Component ─────────────────────────────────────────────────────────────── */

export const WorkflowFold: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const advance = useCallback(() => {
    setActiveIdx((i) => (i + 1) % STEPS.length);
  }, []);

  /* Auto-advance every 3.5 s while auto-play is on */
  useEffect(() => {
    if (!isAutoPlaying) return;
    const timer = setInterval(advance, 3500);
    return () => clearInterval(timer);
  }, [isAutoPlaying, advance]);

  const handleStepClick = (idx: number) => {
    setActiveIdx(idx);
    setIsAutoPlaying(false);
  };

  const active = STEPS[activeIdx];

  return (
    <section className="workflow-section" id="how-it-works">
      <div className="workflow-container">

        {/* ── 3-Column Layout ── */}
        <div className="workflow-grid">

          {/* ── LEFT: Heading + Active Step Detail ── */}
          <div className="workflow-left">
            <div className="light-pill-badge" style={{ marginBottom: '28px' }}>
              <span className="dot" />
              <span>11:30 · How to Use</span>
            </div>

            <h2 className="workflow-h2">
              From <span className="workflow-h2-accent">ID Scan</span>
              <br />to Entry Pass.
            </h2>

            {/* Active Step Detail */}
            <div className="workflow-step-detail" key={activeIdx}>
              <div className="workflow-step-numrow">
                <span className="workflow-step-num">{active.num}</span>
                <span className="workflow-step-divider">/</span>
                <span className="workflow-step-total">04</span>
              </div>

              <div className="workflow-step-icon-title">
                <div className="workflow-step-icon">{active.icon}</div>
                <h3 className="workflow-step-title">{active.title}</h3>
              </div>

              <p className="workflow-step-desc">{active.desc}</p>

              {/* Progress bar */}
              <div className="workflow-progress-track">
                <div
                  className="workflow-progress-fill"
                  style={{ width: `${((activeIdx + 1) / STEPS.length) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* ── CENTER: Phone Mockup ── */}
          <div className="workflow-center">
            <div className="workflow-phone-shell">
              {/* Phone bezel */}
              <div className="wf-phone-notch" />

              {/* Status bar */}
              <div className="wf-status-bar">
                <span className="wf-status-time">{active.phone.statusBar}</span>
                <div className="wf-status-icons">
                  <Wifi size={11} />
                  <span className="wf-battery" />
                </div>
              </div>

              {/* App header */}
              <div className="wf-app-header">
                <span className="wf-app-logo">Gate Shield</span>
                <span className={`wf-app-badge ${active.phone.badgeColor}`}>
                  {active.phone.badge}
                </span>
              </div>

              {/* Screen title */}
              <div className="wf-screen-title-block">
                <div className="wf-screen-title" key={`t-${activeIdx}`}>
                  {active.phone.screenTitle}
                </div>
                <div className="wf-screen-sub">{active.phone.screenSub}</div>
              </div>

              {/* Dynamic body */}
              <div className="wf-phone-body" key={`b-${activeIdx}`}>
                {active.phone.body}
              </div>

              {/* Footer stat strip */}
              <div className="wf-phone-footer">
                <div className="wf-footer-left">
                  <span className="wf-footer-label">{active.phone.footerLabel}</span>
                  <span className="wf-footer-sub">{active.phone.footerSub}</span>
                </div>
                <div className="wf-footer-step-dot-row">
                  {STEPS.map((_, i) => (
                    <span
                      key={i}
                      className={`wf-footer-dot ${i === activeIdx ? 'active' : ''}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* ── RIGHT: Vertical Timeline Steps ── */}
          <div className="workflow-right">
            <div className="wf-timeline-label">YOUR CHECK-IN JOURNEY</div>
            <div className="wf-timeline">
              {STEPS.map((step, idx) => {
                const isActive = idx === activeIdx;
                const isDone = idx < activeIdx;
                return (
                  <button
                    key={step.num}
                    type="button"
                    className={`wf-timeline-step ${isActive ? 'active' : ''} ${isDone ? 'done' : ''}`}
                    onClick={() => handleStepClick(idx)}
                    aria-current={isActive ? 'step' : undefined}
                  >
                    {/* Connector line above (not for first) */}
                    {idx > 0 && (
                      <span
                        className={`wf-timeline-connector ${isDone || isActive ? 'filled' : ''}`}
                      />
                    )}

                    {/* Dot */}
                    <span className="wf-timeline-dot">
                      {isDone ? <CheckCircle2 size={14} /> : null}
                    </span>

                    {/* Text */}
                    <div className="wf-timeline-text">
                      <span className="wf-timeline-time">
                        STEP {step.num} · {step.time} AM
                      </span>
                      <span className="wf-timeline-name">{step.title}</span>
                    </div>

                    {isActive && <ChevronRight size={15} className="wf-timeline-arrow" />}
                  </button>
                );
              })}
            </div>

            {/* Auto-play toggle */}
            <button
              type="button"
              className={`wf-autoplay-btn ${isAutoPlaying ? 'on' : 'off'}`}
              onClick={() => setIsAutoPlaying((v) => !v)}
              aria-label="Toggle auto-play"
            >
              <span className={`wf-autoplay-dot ${isAutoPlaying ? 'on' : ''}`} />
              {isAutoPlaying ? 'Auto-advancing' : 'Resume auto-play'}
            </button>
          </div>

        </div>
      </div>
    </section>
  );
};
