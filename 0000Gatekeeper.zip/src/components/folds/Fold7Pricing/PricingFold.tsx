'use client';

import React from 'react';
import Link from 'next/link';
import { Check, Star } from 'lucide-react';

export const PricingFold: React.FC = () => {
  return (
    <section className="pricing-section" id="pricing">
      <div className="pricing-container">
        {/* Section Header */}
        <div className="pricing-header">
          <div className="light-pill-badge">
            <span className="dot" />
            <span>12:00 · Transparent Pricing</span>
          </div>

          <h2 className="pricing-h2">The Right Solution at the Right Price</h2>

          <p className="pricing-subheadline">
            Simple pricing with no hidden fees. Flexible plans for organizations of all sizes.
          </p>
        </div>

        {/* 3-Card Grid matching source screenshot */}
        <div className="pricing-cards-grid">
          {/* Card 1: Starter */}
          <div className="pricing-card card-starter">
            <div className="pricing-card-inner">
              <h3 className="card-title">Starter</h3>

              <div className="card-price-row">
                <span className="price-currency">PKR</span>
                <span className="price-amount">1,600</span>
                <span className="price-period">/month /location</span>
              </div>

              <div className="card-billing-info">
                <p className="billing-annual">Billed annually at PKR 19,200</p>
                <p className="billing-savings">Save PKR 4,800 (3 months free)</p>
              </div>

              <div className="card-features-list">
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>300 check-ins /month</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Up to 50 Employees</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Single location</span>
                </div>
              </div>

              <div className="card-action-wrap">
                <Link href="#contact" className="pricing-action-btn outline-btn">
                  Sign Up
                </Link>
              </div>
            </div>
          </div>

          {/* Card 2: Premium (Recommended - GateShield Primary Blue) */}
          <div className="pricing-card card-premium-recommended">
            {/* Top Recommended Banner */}
            <div className="recommended-top-banner">
              <Star size={13} fill="#ffffff" color="#ffffff" />
              <span>Recommended</span>
            </div>

            <div className="pricing-card-inner highlight-inner">
              <h3 className="card-title text-white">Premium</h3>

              <div className="card-price-row text-white">
                <span className="price-currency text-white-dim">PKR</span>
                <span className="price-amount text-white">3,200</span>
                <span className="price-period text-white-dim">/month /location</span>
              </div>

              <div className="card-billing-info">
                <p className="billing-annual text-white-dim">Billed annually at PKR 38,400</p>
                <p className="billing-savings text-white-highlight">Save PKR 9,600 (3 months free)</p>
              </div>

              <div className="card-features-list">
                <div className="feature-item text-white">
                  <div className="feature-check white">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>1000 check-ins /month</span>
                </div>
                <div className="feature-item text-white">
                  <div className="feature-check white">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Up to 200 Employees</span>
                </div>
                <div className="feature-item text-white">
                  <div className="feature-check white">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Multiple locations</span>
                </div>
              </div>

              <div className="card-action-wrap">
                <Link href="#contact" className="pricing-action-btn solid-white-btn">
                  Sign Up
                </Link>
              </div>
            </div>
          </div>

          {/* Card 3: Enterprise */}
          <div className="pricing-card card-enterprise">
            <div className="pricing-card-inner">
              <h3 className="card-title">Enterprise</h3>

              <div className="card-price-row connect-row">
                <span className="connect-heading">Connect</span>
              </div>

              <div className="card-features-list">
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Unlimited visitors</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Category based form</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Third party integration</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Black listing</span>
                </div>
                <div className="feature-item">
                  <div className="feature-check green">
                    <Check size={13} strokeWidth={2.8} />
                  </div>
                  <span>Evacuation alerts</span>
                </div>
              </div>

              <div className="card-action-wrap">
                <Link href="#contact" className="pricing-action-btn outline-btn">
                  Connect
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
