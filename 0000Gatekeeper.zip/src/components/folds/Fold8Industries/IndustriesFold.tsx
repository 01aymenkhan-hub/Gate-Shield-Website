'use client';

import React from 'react';
import {
  Factory,
  Warehouse,
  Building2,
  Presentation,
  Ticket,
  Home,
  HeartPulse,
  GraduationCap,
} from 'lucide-react';

interface IndustryItem {
  id: string;
  title: string;
  description: string;
  tag: string;
  icon: React.ReactNode;
}

const industries: IndustryItem[] = [
  {
    id: 'factories',
    title: 'Factories',
    description: 'Manage visitor entry and keep accurate records of everyone entering your facility.',
    tag: 'Perimeter & Safety',
    icon: <Factory size={22} />,
  },
  {
    id: 'warehouses',
    title: 'Warehouses',
    description: 'Track visitors and contractors while keeping site access organized.',
    tag: 'Logistics & Docks',
    icon: <Warehouse size={22} />,
  },
  {
    id: 'offices',
    title: 'Offices',
    description: 'Manage visitors and interview candidates from arrival to check-in.',
    tag: 'Corporate Lobby',
    icon: <Building2 size={22} />,
  },
  {
    id: 'exhibitions',
    title: 'Exhibitions',
    description: 'Keep guest lists organized and simplify entry for visitors and VIPs.',
    tag: 'Expos & Trade Shows',
    icon: <Presentation size={22} />,
  },
  {
    id: 'concerts',
    title: 'Concerts & Events',
    description: 'Generate tickets and verify them at entry for a smoother check-in experience.',
    tag: 'High-Volume Turnstiles',
    icon: <Ticket size={22} />,
  },
  {
    id: 'residential',
    title: 'Residential Societies',
    description: 'Manage guest and visitor entry with organized digital records.',
    tag: 'Gated Communities',
    icon: <Home size={22} />,
  },
  {
    id: 'hospitals',
    title: 'Hospitals',
    description: 'Manage visitor access and appointments for a more organized reception.',
    tag: 'Healthcare Clinics',
    icon: <HeartPulse size={22} />,
  },
  {
    id: 'education',
    title: 'Educational Institutions',
    description: 'Manage campus visitors, interview candidates, and entry records with ease.',
    tag: 'Campuses & Schools',
    icon: <GraduationCap size={22} />,
  },
];

export const IndustriesFold: React.FC = () => {
  return (
    <section className="industries-section" id="industries">
      <div className="industries-container">
        {/* Section Header */}
        <div className="industries-header">
          <div className="light-pill-badge">
            <span className="dot" />
            <span>12:30 · Industries We Serve</span>
          </div>

          <h2 className="industries-h2">One Solution for Every Industry</h2>

          <p className="industries-subheadline">
            From factory gates to office receptions, Gate Shield helps you manage visitors, access, and everyday operations with ease.
          </p>
        </div>

        {/* 8-Card Responsive Bento Grid */}
        <div className="industries-grid">
          {industries.map((ind) => (
            <div key={ind.id} className="industry-card">
              <div className="industry-card-top">
                <div className="industry-icon-box">{ind.icon}</div>
                <span className="industry-tag">{ind.tag}</span>
              </div>

              <div className="industry-card-body">
                <h3 className="industry-title">{ind.title}</h3>
                <p className="industry-desc">{ind.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
